# Kingfisher plc (B&Q) Financial Performance Analysis

An Excel analysis of three years of results from Kingfisher plc, the owner of B&Q, Screwfix, Castorama and Brico Dépôt (FY23/24 to FY25/26, plus H1 26/27), with a 5-slide PowerPoint summary.

**Tools:** Microsoft Excel (formula-linked ratio model, charts), PowerPoint
**Data:** Kingfisher's published results announcements and annual reports. Every input cell names its source.

## Files

- `Kingfisher_Financial_Analysis.xlsx`
  - **Summary:** key metrics, findings and charts
  - **Financials:** reported figures, typed in blue with a source for each row
  - **Ratios:** growth, margins, cash conversion, dividend cover and net debt, all as formulas
  - **Regions:** like-for-like sales by region and brand
  - **Outlook:** FY26/27 guidance and what the second half (H2) needs to deliver
- `Kingfisher_Results_Summary.pptx`: a 5-slide summary of the findings

## Key findings

1. Sales were flat at about £12.9bn over three years, but returned to growth in FY25/26 (+1.3%, like-for-like +1.1%).
2. Growth came from the UK: B&Q +3.3% and Screwfix +3.2% like-for-like, while France (-2.2%) and Poland (-1.1%) fell.
3. Gross margin rose 130bps in two years (36.8% to 38.1%). This drove profit, not sales volume.
4. Adjusted profit before tax rose 6% to £560m. Excluding the previous year's £33m one-off business rates refund, underlying growth was about 13%.
5. Free cash flow was steady at £511–514m a year (around 91% of adjusted profit), and net debt fell £137m.
6. Guidance was upgraded to £595–635m in September 2026. The midpoint needs H2 profit to grow about 10%.
